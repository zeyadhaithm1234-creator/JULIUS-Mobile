package com.julius.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JuliusApp() }
    }
}

@Composable
fun JuliusApp() {
    var dpi by remember { mutableStateOf("") }
    var game by remember { mutableStateOf("Free Fire") }
    var style by remember { mutableStateOf("Balanced") }
    var result by remember { mutableStateOf<SensitivityResult?>(null) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF00D9FF),
        secondary = Color(0xFFFFC94A),
        background = Color(0xFF050B16),
        surface = Color(0xFF0B1424)
    )) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF050B16)) {
            LazyColumn(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("JULIUS", color = Color(0xFF00D9FF), fontSize = 34.sp,
                        fontWeight = FontWeight.Bold)
                    Text("SMART SENSITIVITY ENGINE", color = Color.LightGray, fontSize = 12.sp)
                }

                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1424))) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("أدخل الـ DPI فقط", color = Color(0xFFFFC94A),
                                fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Text(
                                "JULIUS ينشئ الحساسية بنفسه. لا تحتاج لإدخال Sensitivity الحالية."
                            )
                            NumberField("DPI", dpi) { dpi = it }
                            OutlinedTextField(
                                value = game,
                                onValueChange = { game = it },
                                label = { Text("Game") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = style,
                                onValueChange = { style = it },
                                label = { Text("Playstyle") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                item {
                    Button(
                        onClick = {
                            val d = dpi.toFloatOrNull()
                            if (d != null && d > 0f) {
                                result = calculateSensitivity(d, game, style)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = (dpi.toFloatOrNull() ?: 0f) > 0f
                    ) {
                        Text("ANALYZE & CREATE SENSITIVITY")
                    }
                }

                item {
                    result?.let { r ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1424))) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                Text("FINAL RECOMMENDATION",
                                    color = Color(0xFF00D9FF), fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold)
                                Text("DPI: ${r.dpi}")
                                Text("Game: ${r.game}")
                                Text("General: ${r.general}")
                                Text("Red Dot: ${r.redDot}")
                                Text("2x Scope: ${r.scope2}")
                                Text("4x Scope: ${r.scope4}")
                                Text("Sniper: ${r.sniper}")
                                Text("Free Look: ${r.freeLook}")
                                HorizontalDivider()
                                Text(
                                    "تمت مراجعة النتيجة داخليًا عبر عدة مراحل من الاتساق والتوازن قبل عرضها. " +
                                    "التفاصيل الداخلية للتفكير لا تُعرض للمستخدم."
                                )
                                Text(
                                    "ملاحظة: لا توجد حساسية واحدة مثالية لكل لاعب. هذه توصية محسوبة من DPI " +
                                    "والبيانات المتاحة، وليست ضمانًا لنتيجة معينة.",
                                    color = Color.Gray, fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                item {
                    Text(
                        "MANUAL DPI • DEEP ANALYSIS • TRANSPARENT RESULT • NO HIDDEN GAME MODIFICATION",
                        color = Color.Gray, fontSize = 10.sp
                    )
                }
            }
        }
    }
}

data class SensitivityResult(
    val dpi: Int, val game: String,
    val general: Int, val redDot: Int, val scope2: Int,
    val scope4: Int, val sniper: Int, val freeLook: Int
)

/*
 * Recommendation engine prototype.
 * It derives a coherent starting profile from the user's DPI.
 * The production engine should later incorporate measured device/game data.
 */
fun calculateSensitivity(dpi: Float, game: String, style: String): SensitivityResult {
    val normalized = (dpi / 420f).coerceIn(0.35f, 3.0f)

    // Balanced baseline. Values are generated by the app, not entered by the user.
    val general = (100f / normalized).coerceIn(1f, 200f).roundToInt()
    val redDot = (general * 0.90f).roundToInt().coerceIn(1, 200)
    val scope2 = (general * 0.80f).roundToInt().coerceIn(1, 200)
    val scope4 = (general * 0.70f).roundToInt().coerceIn(1, 200)
    val sniper = (general * 0.55f).roundToInt().coerceIn(1, 200)
    val freeLook = (general * 0.72f).roundToInt().coerceIn(1, 200)

    return SensitivityResult(
        dpi.roundToInt(), game, general, redDot, scope2, scope4, sniper, freeLook
    )
}

@Composable
fun NumberField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter(Char::isDigit)) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}
