# بناء JULIUS Mobile كـ APK من GitHub

1. أنشئ Repository جديد على GitHub.
2. ارفع **كل محتويات هذا المشروع** إلى الـRepository، وليس ملف ZIP نفسه داخل Repository.
3. تأكد أن الملف موجود في:
   `.github/workflows/build-apk.yml`
4. اعمل Commit إلى فرع `main` أو `master`.
5. افتح تبويب **Actions** في Repository.
6. اختر **Build JULIUS APK**.
7. اضغط **Run workflow** إذا لم يبدأ تلقائيًا.
8. بعد نجاح البناء، افتح نتيجة الـworkflow وستجد قسم **Artifacts**.
9. نزّل `JULIUS-Mobile-debug`.
10. فك الضغط، ثم ستجد `app-debug.apk` وتستطيع تثبيته على Android.

الـWorkflow يستخدم JDK 17 وGradle 8.11.1 ويبني Debug APK.
